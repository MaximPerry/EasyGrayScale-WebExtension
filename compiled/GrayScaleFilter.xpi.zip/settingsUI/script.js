﻿document.getElementById("slashon").onclick = function () {
    browser.tabs.create({ url: "http://www.slashon.ca" });
};